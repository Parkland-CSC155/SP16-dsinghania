console.log("Dipty Singhania");
console.log("StudentID - 1470288");
console.log("email - dsinghania1@stu.parkland.edu");
console.log("I am taking this class to learn Web programming and to get a certificate in Web development.");